/**
 * 
 */
package com.canteen.ordering.service;

import java.util.List;

import com.canteen.ordering.dto.AccountMasterDetail;

/**
 * @author Sneha Ashok
 *
 */
public interface OrderingService {
	public List<AccountMasterDetail> getAllAccountMasterDetail();

}
