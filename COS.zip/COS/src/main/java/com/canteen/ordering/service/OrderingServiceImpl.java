/**
 * 
 */
package com.canteen.ordering.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.ordering.dao.OrderingDAO;
import com.canteen.ordering.dto.AccountMasterDetail;

/**
 * @author Sneha Ashok
 *
 */

@Service("orderservice")
@Transactional
public class OrderingServiceImpl implements OrderingService {

	@Autowired
	private OrderingDAO orderdao;
	
	@Override
	public List<AccountMasterDetail> getAllAccountMasterDetail() {
		return orderdao.getAllAccountMasterDetail();
	}

}
