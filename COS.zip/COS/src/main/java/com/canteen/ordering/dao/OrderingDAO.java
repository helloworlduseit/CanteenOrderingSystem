/**
 * 
 */
package com.canteen.ordering.dao;

import java.util.List;

import com.canteen.ordering.dto.AccountMasterDetail;

/**
 * @author Sneha Ashok
 *
 */
public interface OrderingDAO {
	public List<AccountMasterDetail> getAllAccountMasterDetail();

}
