/**
 * 
 */
package com.canteen.ordering.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.canteen.ordering.dto.AccountMasterDetail;

/**
 * @author Sneha Ashok
 *
 */
@Repository("orderdao")
public class OrderingDAOImpl implements OrderingDAO {
	
	@PersistenceContext
	EntityManager entitymanager;


	@Override
	public List<AccountMasterDetail> getAllAccountMasterDetail() {
		Query query=entitymanager.createQuery("FROM AccountMasterDetail");
		return query.getResultList();
	}

}
