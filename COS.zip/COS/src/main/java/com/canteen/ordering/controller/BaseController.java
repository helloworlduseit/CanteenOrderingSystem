/**
 * 
 */
package com.canteen.ordering.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.canteen.ordering.dto.AccountMasterDetail;
import com.canteen.ordering.service.OrderingService;

/**
 * @author Sneha Ashok
 *
 */
@Controller
public class BaseController {
	
	@Autowired
	private OrderingService orderservice;
	
	@RequestMapping(value="all", method=RequestMethod.GET)
	public String show(Model model)
	{
		List<AccountMasterDetail> list = orderservice.getAllAccountMasterDetail();
		for(AccountMasterDetail i : list){
			i.toString();
		}
		
		//model.addAttribute("my", new EmployeeDetails());
		return "Home";
	}


}
