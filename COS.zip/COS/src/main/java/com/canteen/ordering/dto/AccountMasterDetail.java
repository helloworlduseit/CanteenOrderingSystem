/**
 * 
 */
package com.canteen.ordering.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * @author Sneha Ashok
 *
 */
@Entity
@Table(name="tab_account_master ")
public class AccountMasterDetail implements Serializable {
	@Id
	@Column(name="cust_id")
	private Integer customerId;
	
	@Column(name="cust_password")
	private String customerPass;
	
	@Column(name="cust_type")
	private String customerType;
	
	@Column(name="cust_name")
	private String customerNmae;
	
	@Column(name="cust_mobile")
	private Double custMobile;

	/**
	 * @return the customerId
	 */
	public Integer getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerPass
	 */
	public String getCustomerPass() {
		return customerPass;
	}

	/**
	 * @param customerPass the customerPass to set
	 */
	public void setCustomerPass(String customerPass) {
		this.customerPass = customerPass;
	}

	/**
	 * @return the customerType
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * @param customerType the customerType to set
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	/**
	 * @return the customerNmae
	 */
	public String getCustomerNmae() {
		return customerNmae;
	}

	/**
	 * @param customerNmae the customerNmae to set
	 */
	public void setCustomerNmae(String customerNmae) {
		this.customerNmae = customerNmae;
	}

	/**
	 * @return the custMobile
	 */
	public Double getCustMobile() {
		return custMobile;
	}

	/**
	 * @param custMobile the custMobile to set
	 */
	public void setCustMobile(Double custMobile) {
		this.custMobile = custMobile;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountMasterDetail [customerId=" + customerId + ", customerPass=" + customerPass + ", customerType="
				+ customerType + ", customerNmae=" + customerNmae + ", custMobile=" + custMobile + "]";
	}
	
}
